package game;

public class Player {
    int base; //進塁　人数
    int hp; //攻撃者の生命　０場合、打席　１人数をアウトする
    int batterout;  //打席アウト人数、　3人数　change
    int baselevel; //進塁ために、4四回　up　進塁　1個
    int ball;

    Player(){
        this.base = 0;
        this.hp = 3;
        batterout = 0;
        baselevel = 0;
    }
    public void playstart(Team team,  int round) {
            int i = 1;
            while (true) {
                System.out.println(team.name + "チームの攻撃は"+"第"+(round+1)+"回の" + i + "攻撃");
                //ピッチ
                int ball = pitch();
                hit(team,ball,round);
                if (batterout >= 3) {
                    break;
                }
                System.out.println("-----------------------------------");
                System.out.println(team.name + "の得点:" + team.getScores()[round]);
                System.out.println("-----------------------------------");
                i++;
            }
    }
    public int pitch() {
        ball = new java.util.Random().nextInt(100) + 1;
        return ball;
    }

    public void hit(Team team, int ball , int round) {
        int hittype = new java.util.Random().nextInt(2) + 1;
        if (ball < 45) {//ボール
            if(hittype == 1) {
                delBatterHp();
                System.out.println("ボールです。" + team.name + ": ボール打ちました。" );
            } else {
                addBaseLevel(team, round);
                System.out.println("ボールです。" + team.name + "はボール打ってないです。1/4　進塁です。");
            }
        } else if (ball >95) {//デットボール
            goBase(team, round);
            System.out.println("デットボールです。" + "デットボールなので" + team.name + "進塁しました。");
        } else {//ストライク
            switch (hittype) {
                case 1:
                    int strike = new java.util.Random().nextInt(10) + 1;
                    StrikeType(team, round, strike);
                    break;
                case 2:
                    delBatterHp();
                    System.out.println(team.name + ": ボール打ってないです。");
                    break;
                default:
                    break;
            }
        }
    }
    public void goBase(Team team, int round){
        this.base += 1;
        if(base == 4) {
            team.setScore(round, 1);
            base = 3;
        }
        System.out.println("進塁　人数:" + base);
    }
    public void Defense(){
        batterout+=(base+1);
      //  BattedOut();
    }
    public void BattedOut() {
        batterout += 1;
        System.out.println("アウト人数:" + batterout );
    }
    public void delBatterHp() {
        hp -= 1;
        if(hp == 0) {
            BattedOut();
            hp = 3;
        }
        System.out.println("残りHP:" + hp );
    }
    public void addBaseLevel(Team team, int round) {
        baselevel += 1;
        if(baselevel % 4 == 0) {
            goBase(team, round);
            baselevel = 0;
        }
        System.out.println("1/4進塁の個数" + baselevel);
    }
    public void StrikeType(Team team, int round, int strike) {
        if(strike == 1 ) {
            team.setScore(round, base + 1);
            System.out.println("ストライク場合で、" + team.name + "はホームランを打ちました。得点："+ (base + 1));
            base=0;
        }
        else if(strike >= 2 && strike<=4) {
            goBase(team, round);
            System.out.println("ストライク場合で、"  + team.name + "は安打を打ちました。" );
        }
        else if(strike == 5) {
            Defense();
            System.out.println("ストライク場合で、"  + team.name + "はフォース アウトしました。");
        }
        else {
            delBatterHp();
            System.out.println("ストライク場合で、"  + team.name + "打たれてないと線外を打ちました。");
        }

    }
}
